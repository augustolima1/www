<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class MY_Model extends CI_Model {
  // Variável que define o nome da tabela
  var $table = "";
  //$this->load->database();
  //var $this->db = $this->load->database("sucot", TRUE);
  /**
  * Método Construtor
  */
  function __construct() {
    parent::__construct();
  }
  /**
  * Insere um registro na tabela
  *
  * @param array $data Dados a serem inseridos
  *
  * @return boolean
  */
  function salva($data) {
    if(!isset($data))
      return false;
    return $this->db->insert($this->table, $data);
  }
  /**
  * Recupera um registro a partir de um ID
  *
  * @param integer $id ID do registro a ser recuperado
  *
  * @return array
  */
  function getBy($campo,$valor) {
    if(is_null($valor))
      return false;
    $this->db->where($campo, $valor);
    $query = $this->db->get($this->table);
    if ($query->num_rows() > 0) {
      return $query->row_array();
    } else {
      return array();
    }
  }
  /**
  * Lista todos os registros da tabela
  *
  * @param string $sort Campo para ordenação dos registros
  *
  * @param string $order Tipo de ordenação: ASC ou DESC
  *
  * @return array
  */
  function getAllBy($sort = 'id', $order = 'asc', $cons_condicoes =  array(0=>array("campo"=>"","valor"=>""))) {
    $this->db->order_by($sort, $order);
    foreach ($cons_condicoes as $cons_condicao) {
      //echo($cons_condicao);
        /*echo("<pre>");
        print_r($cons_condicao);
        echo("</pre>");*/
      if ($cons_condicao["campo"]!="") {
        $this->db->where($cons_condicao["campo"], $cons_condicao["valor"]);
      }
    }
    $query = $this->db->get($this->table);
    if ($query->num_rows() > 0) {
      $resultado = $query->result_array();
      $resultado = converteDatasDoVetorParaFormatoBR ($resultado);  
      return $resultado;
    } else {
      return array();
    }
  }

  function getAllByJoin($sort = 'id', $order = 'asc', array $cons_condicoes = array(), array $meus_joins = array()) {
    //$meus_joins =  array(0=>array("tabela2","campo_tabela_1","campo_tabela_2")
    //$cons_condicoes array(0=>array("campo"=>"valor"))
    $this->db->order_by($sort, $order);

      //array_push($meus_joins, $meu_join);
  

    foreach ($cons_condicoes as $campo => $cons_condicao) {
      if ($cons_condicao!="") {
        $this->db->where($campo, $cons_condicao);
      }
    }
    foreach ($meus_joins as $meu_join) {         
      if ($meu_join[0]!="") {
        $this->db->join($meu_join[0],$meu_join[1]."=".$meu_join[2]);
      }
    }
 
    $query = $this->db->get($this->table);
    
    if ($query->num_rows() > 0) {       
      $resultado = $query->result_array();
      foreach ($resultado as $ordem => $registro) {
        $resultado[$ordem] = converteDatasDoVetorParaFormatoBR ($registro);
      }
      return $resultado;
    } else {
      return array();
    }
  }

  function getByJoins($campo,$valor,array $meus_joins = array()) {
    //$meus_joins =  array(0=>array("tabela2","campo_tabela_1","campo_tabela_2")
    if(is_null($valor))
      return false;
    $this->db->where($campo, $valor);
    /*echo ("<pre>");
    print_r($meus_joins);
    echo ("</pre>");*/

    
    foreach ($meus_joins as $meu_join) {
      if ($meu_join[0]!="") {
        $this->db->join($meu_join[0],$meu_join[1]."=".$meu_join[2]);
      }
    }    
    $query = $this->db->get($this->table);
    if ($query->num_rows() > 0) {
      return $query->row_array();
    } else {
      return array();
    }
  }
  

  function getLast($sort, $order = 'desc') {
    $this->db->order_by($sort, $order);
    $this->db->limit(1);
    $query = $this->db->get($this->table);
    if ($query->num_rows() > 0) {
      return $query->result_array();
    } else {
      return array();
    }
  }
  /**
  * Atualiza um registro na tabela
  *
  * @param integer $int ID do registro a ser atualizado
  *
  * @param array $data Dados a serem inseridos
  *
  * @return boolean
  */
  function atualiza($campo, $id, $data) {
    if(is_null($id) || !isset($data))
      return false;
    $this->db->where($campo, $id);
    return $this->db->update($this->table, $data);
  }
  /**
  * Remove um registro na tabela
  *
  * @param integer $int ID do registro a ser removido
  *
  *
  * @return boolean
  */
  function exclui($campo, $id) {
    if(is_null($id))
      return false;
    $this->db->where($campo, $id);
    return $this->db->delete($this->table);
  }

  function deleteAllBy($cons_condicoes =  array(0=>array("campo"=>"","valor"=>"")), $campo_not_in = "", $not_in = array()) {
    foreach ($cons_condicoes as $cons_condicao) {
      if ($cons_condicao["campo"]!="") {
        $this->db->where($cons_condicao["campo"], $cons_condicao["valor"]);
      }
    }
    /*echo ("<pre>");
    echo isset($not_in[0]);
    echo ("</pre>");*/

    if (isset($not_in[0]) && $campo_not_in!="") {
      $this->db->where_not_in($campo_not_in, $not_in);
    }

    echo $this->db->delete($this->table);
  }  
}
/* End of file */