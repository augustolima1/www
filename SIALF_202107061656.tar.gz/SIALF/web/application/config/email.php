<?php

    $config['protocol'] = 'smtp';
    $config['smtp_host'] = '';
    $config['smtp_user'] = '';
    $config['smtp_pass'] = '';
    $config['priority'] = 1;
    $config['mailtype'] = 'html';
    $config['smtp_port'] = 587;

?>
