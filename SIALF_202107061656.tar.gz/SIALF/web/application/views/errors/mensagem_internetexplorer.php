<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Atendimento Logística</title>
    
    <!-- Bootstrap 3.3.7 -->
    <link href="<?= base_url('application/assets/busca/bootstrap.css') ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?= base_url('application/assets/font-awesome/css/font-awesome.min.css') ?>">
    
    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?= base_url('application/assets/busca/one-page-wonder.css') ?>" rel="stylesheet">
    <link href="<?= base_url('application/assets/busca/animate.css') ?>" rel="stylesheet">
    <link href="<?= base_url('application/assets/css/Site.css') ?>" rel="stylesheet">

  </head>

 
  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
      <div class="container">
        <a class="navbar-brand" href="<?= base_url() ?>">
            <img src="<?= base_url('application/assets/img/LOG_icon.png') ?>">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
      </div>
    </nav>

    <header class="masthead text-center text-black">
      <div class="masthead-content">
        <div class="container text-center" style="width: 100%">
            <h1 class="masthead-heading mb-0 texto-sombra animated bounceInDown">Olá, <?= $primeiro_nome ?>!</h1>

            <br>
            <h2 style="font-weight: 400 !important;" class="texto-sombra animated fadeInUp" style="animation-delay: 0.5s;">para uma melhor experiência utilize</h2>

            <br>
            
            <div class="animated fadeInUp" style="animation-delay: 1s;">

                   <div class="text-center margin-top-10">
                        <h2 class="inline-block" style="margin: 0 250px 0;">
                            <i class="fa fa-chrome" aria-hidden="true"></i> Google Chrome
                        </h2>
                        <strong>ou</strong>
                        <h2 class=" inline-block" style="margin: 0;">
                            <i class="fa fa-firefox" aria-hidden="true"></i> Mozilla Firefox
                        </h2>
                   </div>

            </div>

          
        </div>
      </div>

    </header>
    



    

    <!-- Footer -->
    <footer class="py-5 bg-black">
      <div class="container">
        <p class="m-0 text-center text-white small">Atendimento Logística - Copyright &copy; SN Logística Empresarial <?= date("Y") ?></p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <!-- jQuery 3 -->
    <script src="<?= base_url('application/assets/js/jquery.min.js') ?>"></script>
    <!-- Bootstrap 3.3.7 -->
    <script src="<?= base_url('../_bootstrap/js/bootstrap.min.js') ?>"></script>

<script>

$( document ).ready(function() {



});

</script>

</body>

</html>
