$(document).ready(function(){

    $('[data-toggle="tooltip"]').tooltip(); 
    
    $(document).on('click', '.frmInt', function () {
        $(this).select();
    }).on('blur', '.frmInt', function () {
        var str = isNumberInt($(this).val());
        $(this).val(str);
    });
    
    $(document).on('focus', '#textobusca', function () {
        $(this).select();
    }).on('keypress', '#textobusca', function (event) {
        if (event.which == 13) 
        {
            event.preventDefault();
            $('#frmBusca').submit();
        }
    })
    
    $('#btnBusca').click(function(){
        if($('#textobusca').val().length <= 2)
        {
            alert('Digite ao menos 3 caracteres na sua busca!');
            //Colocar modal
        }else{
            $('#frmBusca').submit();
        }
    });
    
    $('#btnFeedback').click(function(){
        $('#modalFeedback').modal('show');
    });
    
    $(document).on('click', '#btnCancelar', function(){
        $('#div_result').empty();
        $('#div_search').slideDown();
    });
    
    $(document).on('click', '#btnEnviarFeedback', function(){
        if(confirm('Confirma o envio do seu feedback?'))
        {
            var dados = $('#frmFeedback').serialize();
            sendFeedback('/index.php/busca/feedback', dados);
        };
    });
    
    $(document).on('click', '#btnRascunho', function(){
        if(confirm('Confirma criação de rascunho?'))
        {
            var frm = $(this).attr('data-frm');
            $('#' + frm).submit();
        };
    });
    
    $(document).on('click', '#btnEnviar', function(){
        if(confirm('Confirma o envio do seu pedido?'))
        {
            var frm = $(this).attr('data-frm');
            $('#' + frm).attr('action','/index.php/busca/save/2');

            if (validaForm(frm)) 
            {
                $('#' + frm).submit();
            }else{
                alert('Preencha todos os campos obrigatórios!');
            }
        };
    });
    
    $('input[data-tam]').change(function () {
        if ($(this).val() != '') 
        {
            var tam = parseInt(this.files[0].size, 10);
            tam = convertSizeUnits(tam);
            var tamMax = parseInt($(this).attr('data-tam'), 10);
            if (tam > tamMax)
            {
                alert('Arquivo não pode ser superior a ' + tamMax + 'Kb!');
                $(this).val('');
            }
        } else {
            alert('Campo obrigatório!');
        }
    });
        
    $('.table-search tbody tr td').click(function(){
        var id = $(this).data('id');
        //alert(id);
        loadPageInner('/index.php/busca/detalhes/' + id, '#div_result');
    });
    
});

function sendFeedback(url, dados) {
    $.ajax({
        url: url,
        type: "POST",
        dataType: "html",
        data: dados,
        cache: false,
        beforeSend: function (xhr) {
            $('#modalFeedback').modal('hide');
            var divbg = '<div class=\"bgModal\"></div>';
            $(divbg).appendTo('body');
            var divlb = '<div class=\"loadingBox\"><img src=\"/application/assets/img/ajax-loader.gif\" align=\"absmiddle\" /></div>';
            $(divlb).appendTo('body');
        },
        success: function (data) {
            //alert(data);
            if (trim(data) == 'S') 
            {
                alert('Obrigado por nos enviar seu feedback!');
                $('#btnFeedback').hide();
            }
            else alert('Não foi possível enviar seu feedback! \n Tente novamente mais tarde.');
        },
        error: function (erro) {
            alert("Erro: " + erro.responseText);
        },
        complete: function (xhr, status) {
            $('.loadingBox').remove();
            $('.bgModal').remove();
        }
    });
}

function loadPageInner(url, tgt) {
    $.ajax({
        url: url,
        type: "GET",
        dataType: "html",
        async: true,
        cache: false,
        beforeSend: function (xhr) {
            
            $(tgt).empty();
            var divbg = '<div class=\"bgModal\"></div>';
            $(divbg).appendTo('body');
            var divlb = '<div class=\"loadingBox\"><img src=\"/application/assets/img/ajax-loader.gif\" align=\"absmiddle\" /></div>';
            $(divlb).appendTo('body');
        },
        success: function (data) {
            $('#div_search').slideUp();
            //alert(data);
            $(tgt).html(data);
        },
        error: function (xhr, status, error) {
            alert(xhr.responseText);
        },
        complete: function (xhr, status) {
            $('.loadingBox').remove();
            $('.bgModal').remove();
            
        }
    });

}

function isNumberInt(numero) {

    var number = numero.toString();
    number = number.replace(/\./g, '');
    number = number.replace(/,/g, '.');
    //alert(number);
    if ($.isNumeric(number)) {
        number = number.split('.');
        var nb = number[0].substring(0, number[0].length);
        return nb;
    } else {
        return "1";
    }
}
function trim(str)
{
    return str.replace(/\s/g,'');
}
function validaForm(frm) {
    var valida = true;
    $('#' + frm + ' input[data-obg|="required"]').each(function () {
        var vlr = $(this).val();
        if (vlr == '')
        {
            $(this).addClass('erroMsg');
            valida = false;
        }
    });
    $('#' + frm + ' textarea[data-obg|="required"]').each(function () {
        var vlr = $(this).val();
        if (vlr == '') {
            $(this).addClass('erroMsg');
            valida = false;
        }
    });
    $('#' + frm + ' input[data-email]').each(function () {
        var vlr = $(this).val();
        if (vlr != '')
        {
            if(!validaEmail(vlr))
            {
                $(this).addClass('erroMsg');
                var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">E-mail inválido!</span>';
                $(this).after(msg);
                valida = false;
            }
        } else {
            $(this).addClass('erroMsg');
            var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">E-mail inválido!</span>';
            $(this).after(msg);
            valida = false;
        }
    });
    $('#' + frm + ' input[data-dt]').each(function () {
        var vlr = $(this).val();
        if (vlr != '')
        {
            if (!validarData(vlr))
            {
                $(this).addClass('erroMsg');
                var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">&nbsp;Data inválida!</span>';
                $(this).after(msg);
                valida = false;
            } else {
                if($(this).data('prm') == 'S')
                {
                    var dts = $(this).data('start');
                    if (!validaStartDate(dts, vlr))
                    {
                        $(this).addClass('erroMsg');
                        var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">&nbsp;Data deve ser maior ou igual a ' + dts + '.</span>';
                        $(this).after(msg);
                        valida = false;
                    }
                } 
            }
        } else {
            $(this).addClass('erroMsg');
            var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">&nbsp;Data inválida!</span>';
            $(this).after(msg);
            valida = false;
        }
    });
    $('#' + frm + ' input[type="file"]').each(function () {
        var arq = ['doc', 'docx', 'zip', 'pdf','xls','xlsx'];
        var fln = $(this).val();
        var ext = fln.split('.').pop();
        var fnd = jQuery.inArray(ext, arq);
        if (fnd == -1)
        {
            $(this).addClass('erroMsg');
            var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">Extensão de arquivo inválida!</span>';
            $(this).after(msg);
            valida = false;
        }
    });
    $('#' + frm + ' input[data-comp]').each(function () {
        var attrComp = $(this).attr('data-comp');
        var vlr = $(this).val();
        var vlrComp = $('#' + attrComp).val();
        if (vlr != vlrComp)
        {
            $(this).addClass('erroMsg');
            var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">Valor divergente!</span>';
            $(this).after(msg);
            valida = false;
        }
    });
    $('#' + frm + ' input[data-tam]').each(function () {
        if ($(this).val() != '') {
            var tam = parseInt(this.files[0].size, 10);
            tam = convertSizeUnits(tam);
            var tamMax = parseInt($(this).attr('data-tam'), 10);
            if (tam > tamMax)
            {
                $(this).addClass('erroMsg');
                var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">Tamanho maior que o permitido!</span>';
                $(this).after(msg);
                valida = false;
            }
        } else {
            $(this).addClass('erroMsg');
            var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">Nenhum arquivo informado!</span>';
            $(this).after(msg);
            valida = false;
        }
    });
    return valida;
}
function ValidaData(data)
{
    //var data = obj.value;
    var dia = data.substring(0,2)
    var mes = data.substring(3,5)
    var ano = data.substring(6,10)
 
    //Criando um objeto Date usando os valores ano, mes e dia.
    var novaData = new Date(ano,(mes-1),dia);
 
    var mesmoDia = parseInt(dia,10) == parseInt(novaData.getDate());
    var mesmoMes = parseInt(mes,10) == parseInt(novaData.getMonth())+1;
    var mesmoAno = parseInt(ano) == parseInt(novaData.getFullYear());
 
    if (!((mesmoDia) && (mesmoMes) && (mesmoAno)))
    {
        alert('Data informada é inválida!');   
        obj.focus();    
        return false;
    }  
    return true;
}
function convertSizeUnits(bytes) {
    if (bytes >= 1024) { bytes = (bytes / 1024).toFixed(2); }
    else if (bytes > 1) { bytes = bytes; }
    else if (bytes == 1) { bytes = bytes; }
    else { bytes = 0; }
    return bytes;
}
function formatSizeUnits(bytes) {
    if (bytes >= 1073741824) { bytes = (bytes / 1073741824).toFixed(2) + ' GB'; }
    else if (bytes >= 1048576) { bytes = (bytes / 1048576).toFixed(2) + ' MB'; }
    else if (bytes >= 1024) { bytes = (bytes / 1024).toFixed(2) + ' KB'; }
    else if (bytes > 1) { bytes = bytes + ' bytes'; }
    else if (bytes == 1) { bytes = bytes + ' byte'; }
    else { bytes = '0 byte'; }
    return bytes;
}

