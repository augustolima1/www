$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
    
    $(document).on('focus', '.frmDt', function(){
        $(this).mask('99/99/9999');
        $(this).select();
    });
    
   
    $(document).on('click', '#btnAlterarSenha', function () {
        $('#modalSenha').modal('show');
    });
    
    $(document).on('click', '.btnOrcFixo', function () {
        if (confirm('Confirma serviço como fixo?')) {
            var id = $(this).data('id');
            var url = '/index.php/chamados/save_fixo';
            var dados = {hfID: id};
            saveDados(url, dados, 'Esse chamado foi marcado como fixo!', 'S');
        }
    });
    
    $(document).on('click', '.frmVlr', function () {
        $(this).select();
    }).on('blur', '.frmVlr', function () {
        var str = fmtDecimal($(this).val());
        $(this).val(str);
    });
    
    $(document).on('click', '.frmInt', function () {
        $(this).select();
    }).on('blur', '.frmInt', function () {
        var str = isNumberInt($(this).val());
        $(this).val(str);
    });

    $(document).on('focus', '.frmFone', function(){

            $(this).mask('(99) 99999-999?9');
    });

    $(document).on('focus', '.frmCtr', function(){
        $(this).mask('99999/9999');
    });	
	
    $(document).on('click', '.btnExcluirItem', function () {
        if (confirm('Confirma exclusão do item?')) 
        {
            var url = '/index.php/chamados/excluir_item';
            var dados = {hfID: $(this).data('id'), hfCtr: $(this).data('ctr'), hfIdd: $(this).data('idd'), hfCoServico: $(this).data('coservico')};
            delDadosInner(url, dados, '#tb_load');
        }
    });
    
    $(document).on('click', '.btnFecharOrcamento', function () {
        if (confirm('Confirma fechamento do orçamento?')) 
        {
            var url = '/index.php/chamados/fechar_orcamento';
            var dados = {hfID: $(this).data('id')};
            saveDados(url, dados, 'Orçamento foi finalizado!', 'S');
        }
    });
    
    $(document).on('click', '.btnReabrirOrcamento', function () {
        if (confirm('Confirma reabertura do orçamento?')) 
        {
            var url = '/index.php/chamados/reabrir_orcamento';
            var dados = {hfID: $(this).data('id')};
            saveDados(url, dados, 'Orçamento foi reaberto!', 'S');
        }
    });
    
    /*
    $(document).on('click', '#btnServicoExecutado', function () {
        if (confirm('Confirma execução do serviço?')) {
            var id = $(this).data('id');
            var url = '/index.php/chamados/save_execucao';
            var dados = {hfID: id};
            saveDados(url, dados, 'Esse chamado foi marcado como executado!', 'S');
        }
    });
    */
   
    $(document).on('click', '.btnCustosItem', function () {
        var id = $(this).data('id');
        var ctr = $(this).data('ctr');
        
        var url = '/index.php/chamados/custos';
        var dados = {hfID: id, hfCtr: ctr};
        loadPageFull('#div_load', url, dados);
        $('#modalCusto').modal('show');
    });
    
    $(document).on('click', '.btnSaveInner', function () {
        if (confirm('Confirma?')) {
            var frm = $(this).attr('data-frm');
            
            if (validaForm(frm)) {
                var msg = $(this).data('msg');
                var url = $(this).data('url');
                var tgt = $(this).data('tgt');
                var url_rd = $(this).data('rd');
                var dados = $('#' + frm).serialize();
                //zeraForm(frm);
                saveDadosInner(url, dados, tgt, msg, url_rd);
            }
        }
    });
    
    $(document).on('click', '.btnSaveInnerNoConfirmation', function () {
        var frm = $(this).attr('data-frm');
        
        if (validaForm(frm)) {
            var msg = $(this).data('msg');
            var url = $(this).data('url');
            var tgt = $(this).data('tgt');
            var url_rd = $(this).data('rd');
            var dados = $('#' + frm).serialize();
            //zeraForm(frm);
            saveDadosInner(url, dados, tgt, msg, url_rd);
        }
    });
    
    $(document).on('click', '.btnSaveInnerReload', function () {
        if (confirm('Confirma?')) {
            var frm = $(this).attr('data-frm');
            
            if (validaForm(frm)) {
                var msg = $(this).data('msg');
                var url = $(this).data('url');
                var tgt = $(this).data('tgt');
                var url_rd = $(this).data('rd');
                var dados = $('#' + frm).serialize();
                //zeraForm(frm);
                saveDadosInnerReload(url, dados, tgt, msg, url_rd);
            } else {
				alert('Preencha todos os campos.');
			}
        }
    });
    
    $(document).on('click', '.btnSaveInnerReloadNoConfirmation', function () {
        var frm = $(this).attr('data-frm');
        
        if (validaForm(frm)) {
            var msg = $(this).data('msg');
            var url = $(this).data('url');
            var tgt = $(this).data('tgt');
            var url_rd = $(this).data('rd');
            var dados = $('#' + frm).serialize();
            //zeraForm(frm);
            saveDadosInnerReload(url, dados, tgt, msg, url_rd);
        } else {
			alert('Preencha todos os campos.');
		}
    });
    
    $(document).on('click', '.btnSavePOST', function () {
        if (confirm('Confirma envio dos dados?')) {
            var frm = $(this).attr('data-frm');

            if (validaForm(frm)) 
            {
                $('#' + frm).submit();
            }
        }
    });
});
function saveDados(url, dados, msg, reload) {
    $.ajax({
        url: url,
        type: "POST",
        dataType: "html",
        data: dados,
        cache: false,
        beforeSend: function (xhr) {
            var divbg = '<div class=\"bgModal\"></div>';
            $(divbg).appendTo('body');
            var divlb = '<div class=\"loadingBox\"><img src=\"/application/assets/img/ajax-loader.gif\" align=\"absmiddle\" /></div>';
            $(divlb).appendTo('body');
        },
        success: function (data) {
            //alert(data);
            geraToastr(msg, trim(data), reload, 1000);
        },
        error: function (erro) {
            alert("Erro: " + erro.statusText);
        },
        complete: function (xhr, status) {
            $('.loadingBox').remove();
            $('.bgModal').remove();
        }
    });
}
function saveDadosInner(url, dados, tgt, msg, url_rd) {
    $.ajax({
        url: url,
        type: "POST",
        dataType: "html",
        data: dados,
        cache: false,
        beforeSend: function (xhr) {
            var divbg = '<div class=\"bgModal\"></div>';
            $(divbg).appendTo('body');
            var divlb = '<div class=\"loadingBox\">Gravando...</div>';
            $(divlb).appendTo('body');
        },
        success: function (data) {
	    
            $(tgt).html(data);
            //$('#tb_load_orcamento').html('<tr><td>data</td></tr>');
            geraToastr(msg, 'S');
            //alert(data);
            
        },
        error: function (erro) {
            alert("Erro: " + erro.responseText);
        },
        complete: function (xhr, status) {
            $('.loadingBox').remove();
            $('.bgModal').remove();
        }
    });
}

function saveDadosInnerReload(url, dados, tgt, msg, url_rd) {
    $.ajax({
        url: url,
        type: "POST",
        dataType: "html",
        data: dados,
        cache: false,
        beforeSend: function (xhr) {
            var divbg = '<div class=\"bgModal\"></div>';
            $(divbg).appendTo('body');
            var divlb = '<div class=\"loadingBox\">Gravando...</div>';
            $(divlb).appendTo('body');
        },
        success: function (data) {
	    
            $(tgt).html(data);
            //$('#tb_load_orcamento').html('<tr><td>data</td></tr>');
            geraToastr(msg, 'S');
            document.location.reload();
            
        },
        error: function (erro) {
            alert("Erro: " + erro.responseText);
        },
        complete: function (xhr, status) {
            $('.loadingBox').remove();
            $('.bgModal').remove();
        }
    });
}

function delDadosInner(url, dados, tgt) {
    $.ajax({
        url: url,
        type: "POST",
        dataType: "html",
        data: dados,
        cache: false,
        beforeSend: function (xhr) {
            var divbg = '<div class=\"bgModal\"></div>';
            $(divbg).appendTo('body');
            var divlb = '<div class=\"loadingBox\">Excluindo...</div>';
            $(divlb).appendTo('body');
        },
        success: function (data) {
            //alert(data);
            $(tgt).html(data);
        },
        error: function (erro) {
            alert("Erro: " + erro.responseText);
        },
        complete: function (xhr, status) {
            $('.loadingBox').remove();
            $('.bgModal').remove();
        }
    });
}
function loadPageFull(tgt, url, dados) {
    $.ajax({
        url: url,
        type: "POST",
        dataType: "html",
        data: dados,
        cache: false,
        async: true,
        beforeSend: function (xhr) {
            var divbg = '<div class=\"bgModal\"></div>';
            $(divbg).appendTo('body');
            var divlb = '<div class=\"loadingBox\"><img src=\"/application/assets/img/ajax-loader-mini.gif\" align=\"absmiddle\" />&nbsp;Carregando...</div>';
            $(divlb).appendTo('body');
            $(tgt).empty();
        },
        success: function (data) {
            //alert(data);
            $(tgt).html(data);
        },
        error: function (erro) {
            alert("Erro: " + erro.responseText);
        },
        complete: function (xhr, status) {
            $('.loadingBox').remove();
            $('.bgModal').remove();
        }
    });
}
function validaForm(frm) {
    var valida = true;
    $('#' + frm + ' input[data-obg|="required"]').each(function () {
        var vlr = $(this).val();
        if (vlr == '')
        {
            $(this).addClass('erroMsg');
            valida = false;
        }
    });
    $('#' + frm + ' input[data-obg|="float"]').each(function () {
        var vlr = $(this).val();
        if (vlr == '0,00')
        {
            $(this).addClass('erroMsg');
            valida = false;
        }
    });
    $('#' + frm + ' input[data-obg|="int"]').each(function () {
        var vlr = $(this).val();
        if (vlr == '0')
        {
            $(this).addClass('erroMsg');
            valida = false;
        }
    });
    $('#' + frm + ' select[data-obg|="required"]').each(function () {
        var vlr = $(this).val();
        if (vlr == '')
        {
            $(this).addClass('erroMsg');
            valida = false;
        }
    });
    $('#' + frm + ' textarea[data-obg|="required"]').each(function () {
        var vlr = $(this).val();
        if (vlr == '') {
            $(this).addClass('erroMsg');
            valida = false;
        }
    });
    $('#' + frm + ' input[data-email]').each(function () {
        var vlr = $(this).val();
        if (vlr != '')
        {
            if(!validaEmail(vlr))
            {
                $(this).addClass('erroMsg');
                var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">E-mail inválido!</span>';
                $(this).after(msg);
                valida = false;
            }
        } else {
            $(this).addClass('erroMsg');
            var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">E-mail inválido!</span>';
            $(this).after(msg);
            valida = false;
        }
    });
    $('#' + frm + ' input[data-dt]').each(function () {
        var vlr = $(this).val();
        if (vlr != '')
        {
            if (!validarData(vlr))
            {
                $(this).addClass('erroMsg');
                var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">&nbsp;Data inválida!</span>';
                $(this).after(msg);
                valida = false;
            } else {
                if($(this).data('prm') == 'S')
                {
                    var dts = $(this).data('start');
                    if (!validaStartDate(dts, vlr))
                    {
                        $(this).addClass('erroMsg');
                        var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">&nbsp;Data deve ser maior ou igual a ' + dts + '.</span>';
                        $(this).after(msg);
                        valida = false;
                    }
                } 
            }
        } else {
            $(this).addClass('erroMsg');
            var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">&nbsp;Data inválida!</span>';
            $(this).after(msg);
            valida = false;
        }
    });
    $('#' + frm + ' input[type="file"]').each(function () {
        var arq = ['doc', 'docx', 'zip', 'pdf','xls','xlsx'];
        var fln = $(this).val();
        var ext = fln.split('.').pop();
        var fnd = jQuery.inArray(ext, arq);
        if (fnd == -1)
        {
            $(this).addClass('erroMsg');
            var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">Extensão de arquivo inválida!</span>';
            $(this).after(msg);
            valida = false;
        }
    });
    $('#' + frm + ' input[data-comp]').each(function () {
        var attrComp = $(this).attr('data-comp');
        var vlr = $(this).val();
        var vlrComp = $('#' + attrComp).val();
        if (vlr != vlrComp)
        {
            $(this).addClass('erroMsg');
            var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">Valor divergente!</span>';
            $(this).after(msg);
            valida = false;
        }
    });
    $('#' + frm + ' input[data-tam]').each(function () {
        if ($(this).val() != '') {
            var tam = parseInt(this.files[0].size, 10);
            tam = convertSizeUnits(tam);
            var tamMax = parseInt($(this).attr('data-tam'), 10);
            if (tam > tamMax)
            {
                $(this).addClass('erroMsg');
                var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">Tamanho maior que o permitido!</span>';
                $(this).after(msg);
                valida = false;
            }
        } else {
            $(this).addClass('erroMsg');
            var msg = '<span class="erroInputMsg" id="msg-' + $(this).attr('name') + '">Nenhum arquivo informado!</span>';
            $(this).after(msg);
            valida = false;
        }
    });
    return valida;
}
function zeraForm(frm) {
    
    $('#' + frm + ' input[type="text"]').val('');
    $('#' + frm + ' textarea').val('');
    $('#' + frm + ' select').each(function () {
        var id = $(this).attr('id');
        document.getElementById(id).selectedIndex = 0;
    });
	
	$('#' + frm + ' input[type="text"]').each(function () {
		if ($(this).hasClass('erroMsg'))
		{
			var id = $(this).attr('name');
			$(this).removeClass('erroMsg');
			$('#msg-' + id).remove();
		}
	});
	
	$('#' + frm + ' textarea').each(function () {
		if ($(this).hasClass('erroMsg'))
		{
			var id = $(this).attr('name');
			$(this).removeClass('erroMsg');
			$('#msg-' + id).remove();
		}
	});
}
function trim(str)
{
    return str.replace(/\s/g,'');
}
function isNumberInt(numero) {

    var number = numero.toString();
    number = number.replace(/\./g, '');
    number = number.replace(/,/g, '.');
    //alert(number);
    if ($.isNumeric(number) && number != '0') {
        number = number.split('.');
        var nb = number[0].substring(0, number[0].length);
        return nb;
    } else {
        return "1";
    }
}
function geraToastr(msg, tp, reload, timeout = 1500) {
    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": timeout,
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    if (tp == 'S') {

        if (reload == 'S') {
            toastr.options.onHidden = function () { location.reload(true); }
            toastr.success(msg);

        } else {
            toastr.success(msg);
        }

    } else {
        toastr.error(msg);

    }
}
function convertSizeUnits(bytes) {
    if (bytes >= 1024) { bytes = (bytes / 1024).toFixed(2); }
    else if (bytes > 1) { bytes = bytes; }
    else if (bytes == 1) { bytes = bytes; }
    else { bytes = 0; }
    return bytes;
}
function formatSizeUnits(bytes) {
    if (bytes >= 1073741824) { bytes = (bytes / 1073741824).toFixed(2) + ' GB'; }
    else if (bytes >= 1048576) { bytes = (bytes / 1048576).toFixed(2) + ' MB'; }
    else if (bytes >= 1024) { bytes = (bytes / 1024).toFixed(2) + ' KB'; }
    else if (bytes > 1) { bytes = bytes + ' bytes'; }
    else if (bytes == 1) { bytes = bytes + ' byte'; }
    else { bytes = '0 byte'; }
    return bytes;
}
//-----------------------------------------------------------------
// Entrada DD/MM/AAAA
//-----------------------------------------------------------------
function ValidaData(data)
{
    //var data = obj.value;
    var dia = data.substring(0,2)
    var mes = data.substring(3,5)
    var ano = data.substring(6,10)
 
    //Criando um objeto Date usando os valores ano, mes e dia.
    var novaData = new Date(ano,(mes-1),dia);
 
    var mesmoDia = parseInt(dia,10) == parseInt(novaData.getDate());
    var mesmoMes = parseInt(mes,10) == parseInt(novaData.getMonth())+1;
    var mesmoAno = parseInt(ano) == parseInt(novaData.getFullYear());
 
    if (!((mesmoDia) && (mesmoMes) && (mesmoAno)))
    {
        alert('Data informada é inválida!');   
        obj.focus();    
        return false;
    }  
    return true;
}
function selVlrCombo(vlr, cbID) {
    var cb = document.getElementById(cbID);
    for (var i = 0; i < cb.length; i++) {
        var opt = cb.options[i];
        if (opt.value == vlr) {
            cb.selectedIndex = i;
        };
    }
}

function trim(str)
{
    return str.replace(/\s/g,'');
}
function fmtDecimal(numero) {

    var number = numero.toString();
    number = number.replace(/\./g, '');
    number = number.replace(/,/g, '.');

    if ($.isNumeric(number)) {
        number = number.replace(/\./g, ',');

        if (number.indexOf(',') != -1) {
            number = number.split(',');
            var nb = number[0].substring(0, number[0].length);
            var dec = number[1].substring(0, 2);
            var num = nb + '.' + dec;
            return num;
        } else {
            var num = number + '.00';
            return num;
        }

    } else {

        return '1.00';
    }
}

function isNumberInt(numero) {

    var number = numero.toString();
    number = number.replace(/\./g, '');
    number = number.replace(/,/g, '.');
    //alert(number);
    if ($.isNumeric(number) && number != '0') {
        number = number.split('.');
        var nb = number[0].substring(0, number[0].length);
        return nb;
    } else {
        return "1";
    }
}


